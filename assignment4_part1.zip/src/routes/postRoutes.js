import express from 'express';
import {
  getAllPostsHandler,
  getPostByIdHandler,
  createPostHandler,
  updatePostHandler,
  deletePostHandler,
} from '../controllers/postController.js';

//create router
const router = express.Router();
//call controller handler
router.get('/', getAllPostsHandler);
//add route
router.get('/:id', getPostByIdHandler);
router.post('/', createPostHandler);
router.put('/:id', updatePostHandler);
router.delete('/:id', deletePostHandler);
//export router to connect ot main server
export default router;
